/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "topics.json",
    "revision": "76ad19ff26f712fb622e4ffd029b38b1"
  }, {
    "url": "service-worker.js",
    "revision": "c5d14f61b0f90314586e0c41c78cc607"
  }, {
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "manifest.json",
    "revision": "ef6edfd0af41936bfb51780c3281dac9"
  }, {
    "url": "index.html",
    "revision": "809b8114ecd58679934d3e0951ef7596"
  }, {
    "url": "favicon.ico",
    "revision": "7216fd768015ce73f9f51399f7a781a8"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "d14fbfab892af6940f0417f2d85fe0ef"
  }, {
    "url": "VERSION.json",
    "revision": "b4e80633011dac8fc7501bcf94ccec95"
  }, {
    "url": "404.html",
    "revision": "28ddaba0a944e320ddadec6ffa75d3af"
  }, {
    "url": "data/profed/teaching_profession/philosophical_heritage/philosophical_heritage.json",
    "revision": "93dad81964bb8f836ce6c2b8b160cfe6"
  }, {
    "url": "data/gened/rizal/rizal_law/rizal_law.json",
    "revision": "0b61d2a010534671c8fd38107c640a51"
  }, {
    "url": "data/english_majorship/structure_of_english/basic_sentence_pattern/basic_sentence_pattern.json",
    "revision": "74abe6a3e934b464d56bde77dfc22c4c"
  }, {
    "url": "css/theme.css",
    "revision": "b94a5042b9a5e74657468e67c21e9a3b"
  }, {
    "url": "css/style.css",
    "revision": "db253050e812f86a04ae9eea8f6ef706"
  }, {
    "url": "assets/index-CqEOU0yi.js",
    "revision": null
  }, {
    "url": "assets/index-CL6bS6nh.css",
    "revision": null
  }, {
    "url": "assets/icons/icon.svg",
    "revision": null
  }, {
    "url": "assets/icons/icon-maskable-512.png",
    "revision": null
  }, {
    "url": "assets/icons/icon-maskable-192.png",
    "revision": null
  }, {
    "url": "assets/icons/icon-512.png",
    "revision": null
  }, {
    "url": "assets/icons/icon-192.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "d14fbfab892af6940f0417f2d85fe0ef"
  }, {
    "url": "favicon.ico",
    "revision": "7216fd768015ce73f9f51399f7a781a8"
  }, {
    "url": "assets/icons/icon-192.png",
    "revision": "b4548bd1096ada4e2d53ba7bc0d54b99"
  }, {
    "url": "assets/icons/icon-512.png",
    "revision": "8df27cf4883aa9ef7beaf7d0c428b456"
  }, {
    "url": "assets/icons/icon-maskable-192.png",
    "revision": "65f9b06a4c2d61c4de05657f0759963b"
  }, {
    "url": "assets/icons/icon-maskable-512.png",
    "revision": "63b4a2838a3738dc9f15ce0f379ed7ba"
  }, {
    "url": "manifest.webmanifest",
    "revision": "55641bdf6d58b1f452ae881975096024"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
